<?php

/**
* Archivo para  de la validacion de roles 
*
* @author Grupo Desarrollo WEB
* @param $_SESSION con la sesion del usuario $db_config con la configuracion de la base de datos
*/
session_start(); 
require 'admin/config.php';
require 'functions.php';
//verifica que el usuario si ha iniciado sesion
if(!isset($_SESSION['NOMBRE'])){
    header('Location: '.RUTA.'login.php');
}
//valida que el tipo de usuario que ha iniciado sesion es un estudiante 
//para dirigirlo a la pagina correspondiente en este caso el 
$conexion = conexion($db_config);
$estudiante = iniciarSesion('USUARIOS', $conexion);
if ($estudiante['TIPO_USUARIO'] == 'estudiante') {
    require 'views/estudiante.view.php';
}else{
    header('Location: '.RUTA. 'login.php');
}

?>