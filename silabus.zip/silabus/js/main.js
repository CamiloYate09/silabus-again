$(mostrar_datos());

function mostrar_datos(nombre){
	$.ajax({
		url: 'busqueda.php',
		type: 'POST',
		dataType: 'html',
		data: {nombre: nombre},
		})

	.done(function(respuesta) {
		$("#tabla_resultado").html(respuesta);
	})
}

$(document).on('keyup', '#busqueda', function(){
	var valor = $(this).val();
	if (valor != "") 
	{
		mostrar_datos(valor);
	}
	else
	{
		mostrar_datos();
	}

});


