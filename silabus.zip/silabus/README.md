# silabus-nuevo
Este es el repositorio del pryecto silabus EAN para el curso Desarrollo Web,mejorado y con continuidad
