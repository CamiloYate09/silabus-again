<?php
/**
*
* @author Grupo Desarrollo WEB
* 
* s
*/

//iniciamos la sesion
session_start(); 
//traemos los archivos de la conexion 
require 'admin/config.php';
require 'functions.php';

/**
*valida que la sesion del usuario este establecida 
* valida qué tipo de usuario ha ingresado al sistema
* dependienddo el rol del usuario es enviado a la pagina correspondiente
* 
* */
if(!isset($_SESSION['NOMBRE'])){
    header('Location: '.RUTA.'login.php');
}
$conexion = conexion($db_config);
$profesor = iniciarSesion('USUARIOS', $conexion);
if ($profesor['TIPO_USUARIO'] == 'profesor') {
    require 'views/profesor.view.php';
}else{
    header('Location: '.RUTA. 'login.php');
}

?>