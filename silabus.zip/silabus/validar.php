<?php
//iniciamos la sesion
session_start();

//llamamos los archivos correspondientes
require 'admin/config.php';
require 'functions.php';

//comprueba la sesion
if (isset($_SESSION['NOMBRE'])) {
    
    $conexion = conexion($db_config);
    $usuario = iniciarSesion('USUARIOS', $conexion);
 
    //verifica el tipo de usuario
    //si el usuario tiene el rol estudiante
    if ($usuario['TIPO_USUARIO'] == 'estudiante') {
        header('Location: '.RUTA.'estudiante.php');
    }
    //si el usuario tiene el rol profesor
    elseif($usuario['TIPO_USUARIO'] == 'profesor') {
        header('Location: '.RUTA.'profesor.php');
    }
    //si surge algun problema se dirigi a la pagina login 
    else{
        header('Location: '.RUTA.'login.php');
    }    
}else{
    header('Location: '.RUTA.'login.php');
}




?>