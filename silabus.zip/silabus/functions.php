<?php 

	/**
* funcion que hace la conexion a la base de datos 
* Funcion que conecta la base de datos con implementacion POO
* */
	function conexion($db_config){
		try {
			$conexion = new PDO('mysql:host=localhost;dbname='.$db_config['db_name'], $db_config['user'], $db_config['pass']);
			return $conexion;
		} catch (PDOException $e) {
			return false;
		}
	}

	/**
* funcion iniciar sesion
*
* Funcion iniciarSesion para extraer los 
* datos solicitados en el login
* esta funcion esta implementada con POO
* */
	function iniciarSesion($tabla, $conexion){
		$statement = $conexion->prepare("SELECT * FROM $tabla WHERE NOMBRE = :nombre");
		$statement->execute([
			':nombre' => $_SESSION['NOMBRE']
		]);
		return $statement->fetch(PDO::FETCH_ASSOC);
	}

 ?>