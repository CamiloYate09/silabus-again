<?php
#hacemos la conexion
$conexion=mysqli_connect("localhost","root","amunozro8970","silabus");

//verificamos la conexion con la base de datos
if (mysqli_connect_errno()) {
  echo "Fallo la conexion con la base de datos";
  exit();
}
mysqli_set_charset($conexion, "utf8");
 ?>
 