<?php 
//definimos la ruta de la app
define('RUTA', 'http://127.0.0.1/silabus/');

//generamos las variables de las conexion a la base de datos
$db_config = [
	'db_name' => 'silabus',
	'user' => 'root',
	'pass' => 'amunozro8970'
];
 ?>