<?php 
	//iniciamos la sesion
	session_start();
	//traemos los archivos de la conexion a la base de datos
	require 'admin/config.php'; //conexion base de datos
	require 'functions.php'; //

	$errores = '';
	//traemos los campos del formulario del login
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		$usuario = $_POST['nombre']; //name del formulario html
		$password = $_POST['contrasena'];//name del formulario html

		//conexion con la base de datos y la 
		//extraccion de los usuarios para compararlos con los datos ingresado en el form login 
		$conexion = conexion($db_config);
		$statement  = $conexion->prepare('SELECT * FROM USUARIOS WHERE NOMBRE = :nombre AND CONTRASENA = :contrasena');
		$statement->execute([
			':nombre' => $usuario,
			':contrasena' => $password]);

		$resultado = $statement->fetch();

		//validacion de las credenciales ingresadas 
		if ($resultado !== false) {
			$_SESSION['NOMBRE'] = $usuario;
			header('Location: '.RUTA. 'validar.php');
		}else{
			$errores .= '<li class= "error" style="color:red;">Datos incorrectos, por favor intenta nuevamente</li>';
		}
	}
	//traemos la plantilla del login
	require 'views/login.view.php';
 ?>