<?php 
#hacemos la conexion a la base de datos
$conexion=mysqli_connect("localhost","root","amunozro8970","silabus");

//verificamos si la conexion con la base de datos tiene errores o no
if (mysqli_connect_errno()) {
  echo "Fallo la conexion con la base de datos";
  exit();
}
//especificamos el tipo de codificacion
mysqli_set_charset($conexion, "utf8");

//traemos los datos del silabus
$tabla = "";
$query = "SELECT * FROM SILABUS ORDER BY ID_COD_SILABUS";


if (isset($_POST['nombre'])) //parametro que viene de la funcion en el ajax

{	//hacemos la consulta en la base de datos y traemos las coicidencias que se ingresaron
	$q=$conexion->real_escape_string($_POST['nombre']);
	$query="SELECT * FROM SILABUS WHERE
			unidadDeEstudio LIKE '" .$q. "%'";
}

//hacemos una condicion para mostrar los datos en una tabla
$buscarEstudiante = $conexion->query($query);
if ($buscarEstudiante->num_rows > 0) 
{
	$tabla.= 
	'<table class="table table-bordered table-hover">
			<tr>
				<td>UNIDAD_ESTUDIO</td>
				<td>CREDITOS</td>
				<td>FACULTAD</td>
				<td>DURACION DE LA MATERIA</td>
                <td>MODALIDAD</td>
                <td>PDF</td>
			</tr>';
			//recorremos los datos traidos de la base de datos
	while($fila = $buscarEstudiante->fetch_assoc()) 
	{
		$tabla.=
		'<tr>
			<td>'.$fila['unidadDeEstudio'].'</td>
			<td>'.$fila['creditos'].'</td>
			
            <td><a href="files/'.$fila['PDF'].'"></td>
		</tr>';
	}

	$tabla.='</table>';
}else{	
		$tabla.="<div class='alert alert-warning text-center'>
  <strong>No hay datos que coincidan con tu busqueda</strong></div>";
	}

//muestro la tabla
echo $tabla;
 ?>
