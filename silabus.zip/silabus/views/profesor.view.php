<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="./css/profesor.css">
    <link rel="shortcut icon" href="img/icon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
    <title>Home | Syllabus EAN</title>
</head>

<body>
    <div class="container contenedornavbar">
        <nav class="navbar navbar-light bg-light justify-content-between">
            <a class="navbar-brand">Syllabus EAN</a>
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Features</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Pricing</a>
                </li>
            </ul>
            <div class="form-inline">
                <a href="<?php echo RUTA.'close.php' ?>" class="salir badge badge-primary">Salir <i class="fas fa-power-off"></i></a>
            </div>
        </nav>
        <!--<section class="container seccion-busqueda">
        <div>
            <input class="form-control" type="text" name="buscar" id="busqueda" placeholder="busca..." autofocus>
            <section id="tabla_resultado"></section>
        </div>
    </section>-->
        <div class="container formulario">

            <form method="POST" action="PDF.php">
                <div class="form-row">
                    <div class="form-group col-md-1">
                        <label for="año">AÑO</label>
                        <input type="text" name="anio" class="form-control form-control-sm">
                    </div>
                    <div class="form-group col-md-3">
                        <label for="tipo">TIPO</label>
                        <input type="text" name="tipo" class="form-control form-control-sm">
                    </div>
                    <div class="form-group col-md-2">
                        <label for="codigo">CODIGO</label>
                        <input type="text" name="codigo" class="form-control form-control-sm">
                    </div>
                    <div class="form-group col-md-3">
                        <label for="modalidad">MODALIDAD</label>
                        <input type="text" name="modalidad" class="form-control form-control-sm">
                    </div>
                    <div class="form-group col-md-1">
                        <label for="creditos">CREDITOS</label>
                        <input type="text" name="creditos" class="form-control form-control-sm">
                    </div>
                    <div class="form-group col-md-2">
                        <label for="duracion">DURACIÓN</label>
                        <input type="text" name="duracion" class="form-control form-control-sm">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-2">
                        <label for="directo">HORAS AC.DIRECTO</label>
                        <input type="text" name="directo" class="form-control form-control-sm">
                    </div>
                    <div class="form-group col-md-2">
                        <label for="autonomo">HORAS T. AUTÓNOMO</label>
                        <input type="text" name="autonomo" class="form-control form-control-sm">
                    </div>
                    <div class="form-group col-md-2">
                        <label for="totales">HORAS TOTALES</label>
                        <input type="text" name="totales" class="form-control form-control-sm">
                    </div>
                    <div class="form-group col-md-3">
                        <label for="facultad">FACULTAD</label>
                        <input type="text" name="facultad" class="form-control form-control-sm">
                    </div>
                    <div class="form-group col-md-3">
                        <label for="programa">PROGRAMA</label>
                        <input type="text" name="programa" class="form-control form-control-sm">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-12">
                        <label for="unidadDeEstudio">UNIDAD DE ESTUDIO</label>
                        <input type="text" name="unidadDeEstudio" class="form-control form-control-sm">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="pre-requisitos">UNIDADES DE ESTUDIOS PRE-REQUISITOS</label>
                        <textarea class="form-control" name="pre-requisitos" rows="5"></textarea>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="co-requisitos">UNIDADES DE ESTUDIOS CO-REQUISITOS</label>
                        <textarea class="form-control" name="co-requisitos" rows="5"></textarea>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-12">
                        <label for="proposito">PROPÓSITO DEL CURSO</label><br />
                        <textarea class="form-control" name="proposito" rows="7"></textarea>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-1">
                        <label for="version">VERSION</label>
                        <input type="text" name="version" class="form-control form-control-sm">
                    </div>
                    <div class="form-group col-md-1">
                        <label for="FECHA">FECHA</label>
                        <input type="text" name="fecha" class="form-control form-control-sm">
                    </div>
                    <div class="form-group col-md-2">
                        <label for="elaboro">ELABORÓ</label>
                        <input type="text" name="elaborado_por" class="form-control form-control-sm">
                    </div>
                    <div class="form-group col-md-2">
                        <label for="reviso">REVISÓ</label>
                        <input type="text" name="revisado_por" class="form-control form-control-sm">
                    </div>
                    <div class="form-group col-md-2">
                        <label for="aprobo">APROBÓ</label>
                        <input type="text" name="aprobado_por" class="form-control form-control-sm">
                    </div>
                    <div class="form-group col-md-4">
                        <label for="cambio">DESCRIPCION DEL CAMBIO</label>
                        <input type="text" name="cambio" class="form-control form-control-sm">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="evaluacion">EVALUACION</label><br />
                        <textarea name="evaluacion" class="form-control" id="evaluacion" rows="5"></textarea>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="recursos">RECURSOS</label><br />
                        <textarea name="recursos" class="form-control" id="recursos" rows="5"></textarea>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-12">
                        <label for="bibliografia">BIBLIOGRAFIA</label><br />
                        <textarea name="bibliografia" class="form-control" id="bibliografia" rows="5"></textarea>
                    </div>
                </div>
                <button type="submit" name="save" class="btn btn-primary">Guardar</button>
                <button type="submit" name="actualizar" class="btn btn-danger">Actualizar</button>
                <!-- este boton no debe ir aqui, sino en dashboard del profesor -->
                <button type="submit" name="borrar" class="btn btn-secondary">cancelar</button>
            </form>
        </div>
    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/main.js"></script>

</body>

</html>

       