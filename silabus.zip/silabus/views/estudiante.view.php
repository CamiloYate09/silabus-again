
<!DOCTYPE html>
<html lang="en">
<head>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="css/dashboard.css">
	<link rel="shortcut icon" href="img/icon.ico" type="image/x-icon" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css?family=Dosis" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
	<title>Home | Syllabus EAN</title>
	<style>
</style>
</head>
<body>

	<header class="header">
		<div class="icon-user">
			<i class="fas fa-user-circle"></i>
		</div>
		<div class="encabezado">
			<h2>BIENVENIDO ESTUDIANTE</h2>
		</div>
		<div class="btn-salir">
			<a href="<?php echo RUTA.'close.php' ?>" class="btn">Salir</a>
		</div>
		</header>
<section class="container">
	<div>
		<input  class="form-control" type="text" name="buscar" id="busqueda" placeholder="busca..." autofocus>
	<section id="tabla_resultado">
		
	</section>
	</div>

</section>


<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>