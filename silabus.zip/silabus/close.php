<?php
	//inciamos la session
    session_start();
    //llamamos los archivos correspondiente 
    require 'admin/config.php';
    require 'functions.php';
    //destruimos la session cuando el usuario salga
    session_destroy();
    //redirigimos a la pagina login
    header('Location: '.RUTA.'login.php');
?>